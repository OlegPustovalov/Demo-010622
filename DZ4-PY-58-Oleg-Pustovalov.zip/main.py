#Задание 1
geo_logs = [
  {'visit1':['Москва','Россия']},
  #{'visit2':['Дели','Индия']},
  {'visit3':['Владимир','Россия']},
  #{'visit4':['Лиссабон','Португалия']},
  #{'visit5':['Париж','Франция']},
  #{'visit6':['Лиссабон','Португалия']},
  {'visit7':['Тула','Россия']},
  {'visit8':['Тула','Россия']},
  {'visit9':['Курск','Россия']},
  {'visit10':['Архангельск','Россия']}
]
for name_dict in geo_logs:
  for visit, country_list in name_dict.items():
    if 'Россия' not in country_list:
      del geologs [visit]
print (geo_logs)  
#Задание 2
ids = {'user1':[213,213,213,15,213],
       'user2':[54,54,119,119,119],
       'user3':[213,98,98,35]}
list_sum = []
for key_,list_ in ids.items():
  list_sum = list_sum + list_
set_sum = set ( list_sum )
print (set_sum)
#Задание 3
queries = [
  'смотреть сериалы онлайн',
  'новости спорта',
  'афиша кино',
  'курс доллара',
  'сериалы этим летом',
  'курс по питону',
  'сериалы про спорт'
]
list_q_word = []
q_querties = 0
max_q_word = 0
for string_ in queries:
  n = string_.count (' ') + 1
  if n > max_q_word :
    max_q_word = n
  list_q_word.append (n)
  q_querties+=1
i = 1
while i <= max_q_word:
  q1 = list_q_word.count (i)
  procent = round (q1/q_querties*100)
  if i == 1:
    print(f'поисковых запросов из 1 слова - {procent} %')
  else:
    print (f'поисковых запросов из {i} слов - {procent} % ')
  i+=1
#задание 4
stats = {
  'facebook': 55, 'yandex': 120, 'vk': 115,
  'google': 42, 'email': 42, 'ok': 98
}
max_value = 0
for platform, value_ in stats.items():
  if max_value < value_:
    max_value = value_
    max_platform = platform
print (max_platform)